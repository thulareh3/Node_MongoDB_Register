const mongoose = require('mongoose');

const registrationSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
  },
  email: {
    type: String,
    trim: true,
  },
});
var connection = mongoose.createConnection('mongodb://localhost:27017/node-demo-application');
var Registration = connection.model('Registration',registrationSchema);
Registration.findOne({ 'email': 'tk@gmail.com' }, function (err, Registration) {
  if (err) return handleError(err);
  // Prints "Space Ghost is a talk show host".
  console.log('selected %s %s .', Registration.name, Registration.email);
});

module.exports = mongoose.model('Registration', registrationSchema);


