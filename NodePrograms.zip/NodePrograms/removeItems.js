var schema= require('./models/Registration');
const mongoose = require('mongoose');
var connection = mongoose.createConnection('mongodb://localhost:27017/node-demo-application');

var Registration = connection.model('Registration',schema);
Registration.deleteOne({ email: 'thulareh3@gmail.com' }, function (err) {
  if (err) return handleError(err);
  // deleted at most one tank document
});