const mongoose = require('mongoose');

const registrationSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
  },
  email: {
    type: String,
    trim: true,
  },
});
var connection = mongoose.createConnection('mongodb://localhost:27017/node-demo-application');
var Registration = connection.model('Registration',registrationSchema);
Registration.find({ email: 'mk@gmail.com' }, function (err) {
  if (err) return handleError(err);
console.log(Registration);
});

module.exports = mongoose.model('Registration', registrationSchema);


