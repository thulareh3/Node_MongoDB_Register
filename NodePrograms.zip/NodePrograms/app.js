const express = require('express');
const path = require('path');
const routes = require('./routes/index');
//require('bootstrap');

const bodyParser = require('body-parser');

var app = express();
app.use(express.static(__dirname + '/public'));
app.use(express.static('public'));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/', routes);

module.exports = app;
